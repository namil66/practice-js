console.log("JavaScript 모듈");
