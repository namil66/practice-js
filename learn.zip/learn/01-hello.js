// 한 줄 주석 (Single line Comment)
// HTML 파일 내부에 작성하는 대신,
// javascript 파일에 코드 작성

/*
여러 줄 주석
뭐시뭐시기뭐시기
저시기저시기저시기
*/
console.log("안녕! JavaScript 🌈");
